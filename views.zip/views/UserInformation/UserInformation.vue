<template>
    <div>
        个人信息
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>