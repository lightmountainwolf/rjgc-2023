<template>
    <div>
        功能点3
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>