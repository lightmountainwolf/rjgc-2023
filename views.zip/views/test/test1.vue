<template>
    <div>
        功能点1
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>