<template>
    <div>
        功能点2
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>