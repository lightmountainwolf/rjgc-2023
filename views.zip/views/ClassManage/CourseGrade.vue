<template>
    <div>
        课程成绩
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>