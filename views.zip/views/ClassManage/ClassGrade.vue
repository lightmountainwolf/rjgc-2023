<template>
    <div>
        班级成绩
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>