<template>
    <div>
        我的成绩
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>