<template>
    <div>
        个人选课
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>