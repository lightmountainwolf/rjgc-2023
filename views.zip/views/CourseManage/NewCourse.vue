<template>
    <div>
        新建课程
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>